CREATE FUNCTION interval_pl_time(interval, time without time zone)
  RETURNS time without time zone
IMMUTABLE
STRICT
PARALLEL SAFE
COST 1
LANGUAGE SQL
AS $$
select $2 + $1
$$;

