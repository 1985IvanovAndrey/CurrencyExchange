CREATE FUNCTION substring(text, text, text)
  RETURNS text
IMMUTABLE
STRICT
PARALLEL SAFE
COST 1
LANGUAGE SQL
AS $$
select pg_catalog.substring($1, pg_catalog.similar_escape($2, $3))
$$;

